
// Main.java
package main;

import gui.HeapGUI;

public class Main {

    public static void main(String[] args){
        /** program entry point

        Starts the Heap GUI application.
        */
        new HeapGUI();
    }
}
