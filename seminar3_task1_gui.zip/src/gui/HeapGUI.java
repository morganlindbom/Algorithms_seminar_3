
// HeapGUI.java
package gui;

import javax.swing.*;
import java.awt.*;

import task.*;

public class HeapGUI extends JFrame {

    private JTextArea output;

    public HeapGUI(){
        /** GUI constructor

        Creates the graphical interface with buttons for each subtask.
        */

        setTitle("Seminar 3 – Binary Heap Tasks");
        setSize(900,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        output = new JTextArea();
        output.setFont(new Font("Monospaced", Font.PLAIN, 14));
        output.setEditable(false);

        JScrollPane scroll = new JScrollPane(output);

        JPanel buttons = new JPanel();

        JButton a = new JButton("Task 1a");
        JButton b = new JButton("Task 1b");
        JButton c = new JButton("Task 1c");
        JButton d = new JButton("Task 1d");
        JButton e = new JButton("Task 1e");
        JButton all = new JButton("Show All");

        a.addActionListener(ev -> output.setText(TaskA.run()));
        b.addActionListener(ev -> output.setText(TaskB.run()));
        c.addActionListener(ev -> output.setText(TaskC.run()));
        d.addActionListener(ev -> output.setText(TaskD.run()));
        e.addActionListener(ev -> output.setText(TaskE.run()));
        all.addActionListener(ev -> output.setText(TaskAll.run()));

        buttons.add(a);
        buttons.add(b);
        buttons.add(c);
        buttons.add(d);
        buttons.add(e);
        buttons.add(all);

        add(buttons, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        setVisible(true);
    }
}
