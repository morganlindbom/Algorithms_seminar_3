
// TaskB.java
package task;

import heap.BinaryHeap;

public class TaskB {

    public static String run(){
        /** Task 1b execution

        Builds the heap using the linear-time buildHeap algorithm.
        */

        BinaryHeap heap = new BinaryHeap(50);
        int[] input = {10,12,1,14,6,5,8,15,3,9,7,4,11,13,2};

        heap.buildHeap(input);

        return "Task 1b – BuildHeap\n\n" + heap.toString();
    }
}
