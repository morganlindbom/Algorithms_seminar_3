
// TaskE.java
package task;

import heap.BinaryHeap;

public class TaskE {

    public static String run(){
        /** Task 1e execution

        Demonstrates priority queue behavior by inserting values
        and removing the minimum element.
        */

        BinaryHeap heap = new BinaryHeap(1000);

        for(int i=0;i<100;i++){
            heap.insert(i);
        }

        heap.deleteMin();

        return "Task 1e – Priority Queue test\n\nDeleteMin executed";
    }
}
