
// TaskC.java
package task;

import heap.BinaryHeap;

public class TaskC {

    public static String run(){
        /** Task 1c execution

        Demonstrates traversal by printing heap array order
        which corresponds to level-order traversal.
        */

        BinaryHeap heap = new BinaryHeap(50);
        int[] input = {10,12,1,14,6,5,8,15,3,9,7,4,11,13,2};

        heap.buildHeap(input);

        return "Task 1c – Traversal (Level Order)\n\n" + heap.toString();
    }
}
