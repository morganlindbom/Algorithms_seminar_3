
// TaskD.java
package task;

import heap.BinaryHeap;

public class TaskD {

    public static String run(){
        /** Task 1d execution

        Measures time complexity of repeated insert operations.
        */

        BinaryHeap heap = new BinaryHeap(20000);

        long start = System.nanoTime();

        for(int i=0;i<10000;i++){
            heap.insert(i);
        }

        long end = System.nanoTime();

        return "Task 1d – Complexity\n\nInsert time: " + (end-start) + " ns";
    }
}
