
// TaskA.java
package task;

import heap.BinaryHeap;

public class TaskA {

    public static String run(){
        /** Task 1a execution

        Inserts elements one-by-one into an initially empty heap and
        prints the heap after each insertion.
        */

        BinaryHeap heap = new BinaryHeap(50);
        int[] input = {10,12,1,14,6,5,8,15,3,9,7,4,11,13,2};

        StringBuilder sb = new StringBuilder();
        sb.append("Task 1a – Insert sequence\n\n");

        for(int v : input){
            heap.insert(v);
            sb.append("Insert ").append(v).append(" -> ");
            sb.append(heap.toString()).append("\n");
        }

        return sb.toString();
    }
}
